// $Id: libfns.h,v 1.2 2015-07-02 16:03:36-07 - - $

// Library functions not members of any class.

#include "bigint.h"

bigint pow (const bigint& base, const bigint& exponent);

